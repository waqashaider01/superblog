<?php
/*
Plugin Name: 	SuperBlog Addons
Plugin URI: 	https://wpmasters.org/
Description: 	Add additional magazine blocks into Elementor  
Author: 		wpmasters
Author URI: 	https://wpmasters.org/
Version: 		1.0
License:		GPL2+
*/

/*  Copyright 2022  WPMasters (Themnific)

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License, version 2, as 
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

if ( !class_exists( 'SuperBlogAddons' ) ) :

final class SuperBlogAddons {};

////////////
// variables
$superblogaddons_main_file = dirname(__FILE__).'/superblog-addons.php';
$superblogaddons_directory = plugin_dir_url($superblogaddons_main_file);
$superblogaddons_path = dirname(__FILE__);


////////////
// text domain
load_plugin_textdomain('superblog-addons', false, basename( dirname( __FILE__ ) ) . '/languages' );

////////////
// widget
include_once (dirname( __FILE__ ) . '/functions/widget-slider.php');
include_once (dirname( __FILE__ ) . '/functions/widget-slider-vertical.php');
include_once (dirname( __FILE__ ) . '/functions/widget-carousel.php');
include_once (dirname( __FILE__ ) . '/functions/widget-blog.php');
include_once (dirname( __FILE__ ) . '/functions/widget-mag-classic.php');
include_once (dirname( __FILE__ ) . '/functions/widget-mag-plain.php');
include_once (dirname( __FILE__ ) . '/functions/widget-mag-big.php');
include_once (dirname( __FILE__ ) . '/functions/widget-mag-grid.php');
include_once (dirname( __FILE__ ) . '/functions/widget-mag-list.php');
include_once (dirname( __FILE__ ) . '/functions/widget-mag-mosaic.php');
include_once (dirname( __FILE__ ) . '/functions/widget-featured.php');



////////////
// thumb for admin section 1.
function superblogaddons_get_featured_image($post_ID) {  
    $post_thumbnail_id = get_post_thumbnail_id($post_ID);  
    if ($post_thumbnail_id) {  
        $post_thumbnail_img = wp_get_attachment_image_src($post_thumbnail_id, 'thumbnail');  
        return $post_thumbnail_img[0];  
    }  
} 
// thumb for admin section 2. ADD NEW COLUMN  
function superblogaddons_columns_head($defaults) {  
	$defaults['featured_image'] = 'Featured Image';  
	return $defaults;  
}  
// thumb for admin section 3. SHOW THE FEATURED IMAGE  
function superblogaddons_columns_content($column_name, $post_ID) {  
	if ($column_name == 'featured_image') {  
		$post_featured_image = superblogaddons_get_featured_image($post_ID);  
		if ($post_featured_image) {  
			echo '<img style=" width:100px;" src="' . $post_featured_image . '" />';  
		}  
	}  
}  
add_filter('manage_posts_columns', 'superblogaddons_columns_head');  
add_action('manage_posts_custom_column', 'superblogaddons_columns_content', 10, 2); 

endif; // class_exists check

?>
