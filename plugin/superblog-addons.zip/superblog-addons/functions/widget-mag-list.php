<?php
add_action('widgets_init', 'superblogaddons_mag_list');

function superblogaddons_mag_list()
{
	register_widget('superblogaddons_mag_list');
}

class superblogaddons_mag_list extends WP_Widget {
	
	public function __construct() {
		$widget_ops = array('classname' => 'superblogaddons_mag_list', 'description' => esc_html__('!!Posts block for Elementor only!!','superblog-addons'));
       	parent::__construct(false, esc_html__('Themnific: Magazine (List)','superblog-addons'),$widget_ops);  
	}
	
	function widget($args, $instance)
	{
		extract($args);
		
		$layout = isset( $instance['layout'] ) ? esc_attr( $instance['layout'] ) : '';
		$post_type = 'all';
		$categories = isset( $instance['categories'] ) ? esc_attr( $instance['categories'] ) : '';
		$posts = isset( $instance['posts'] ) ? esc_attr( $instance['posts'] ) : '';
		$offset_posts = isset( $instance['offset_posts'] ) ? esc_attr( $instance['offset_posts'] ) : '';
		$excerpt_dis = ! empty( $instance['excerpt_dis'] ) ? '1' : '0';
		$center_text = ! empty( $instance['center_text'] ) ? '0' : '1';
		$title_size = isset( $instance['title_size'] ) ? esc_attr( $instance['title_size'] ) : '';
		$tags_selection = isset( $instance['tags_selection'] ) ? esc_attr( $instance['tags_selection'] ) : '';
		
		echo wp_kses_post($before_widget);
		?>
		
		<?php
		$post_types = get_post_types();
		unset($post_types['page'], $post_types['attachment'], $post_types['revision'], $post_types['nav_menu_item']);
		
		if($post_type == 'all') {
			$post_type_array = $post_types;
		} else {
			$post_type_array = $post_type;
		}
		?>
        
        <div class="widget_block">
            
			<?php
			$recent_posts = new WP_Query(array(
				'showposts' => $posts,
				'ignore_sticky_posts' => 1,
				'cat' => $categories,
				'offset' => esc_attr($offset_posts),
				'post_status' => 'publish',
				'tag' => esc_attr($tags_selection)
			));
			
			?>
            <div class="
            tmnf_wrap <?php echo esc_attr($layout); ?> 
			<?php if( 'on' == $instance[ 'excerpt_dis' ] ){ echo ' excerpt_enabled ';} else {echo ' excerpt_disabled ';} ?>
            <?php if( '1' == $instance[ 'center_text' ] ) : echo ' tmnf_center_text ';endif; ?>
            <?php echo esc_attr($title_size); ?>
            ">
			<?php  while($recent_posts->have_posts()): $recent_posts->the_post(); ?>

				<?php get_template_part('/post-types/post-mag-list'); ?>

			<?php endwhile;wp_reset_postdata(); ?>
			</div>
            
			<div class="clearfix"></div>
            
        </div>
		
		<?php
		echo wp_kses_post($after_widget);
	}
	
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['layout'] = $new_instance['layout'];
		$instance['post_type'] = 'all';
		$instance['categories'] = $new_instance['categories'];
		$instance['posts'] = sanitize_text_field($new_instance['posts']);
		$instance['offset_posts'] = sanitize_text_field($new_instance['offset_posts']);
		$instance['excerpt_dis']        = ! empty( $new_instance['excerpt_dis'] ) ? 1 : 0;
		$instance['center_text']        = ! empty( $new_instance['center_text'] ) ? 1 : 0;
		$instance['title_size'] = $new_instance['title_size'];
		$instance['tags_selection'] = sanitize_text_field($new_instance['tags_selection']);
		
		return $instance;
	}

	function form($instance)
	{
		$defaults = array('post_type' => 'all', 'categories' => 'all', 'posts' => 4, 'layout' => 'tmnf_columns_1','offset_posts' => '','tags_selection' => '');
		$excerpt_dis        = isset( $instance['excerpt_dis'] ) ? (bool) $instance['excerpt_dis'] : false;
		$center_text        = isset( $instance['center_text'] ) ? (bool) $instance['center_text'] : false;
		$instance = wp_parse_args((array) $instance, $defaults); ?>

		
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('categories')); ?>"><?php esc_html_e('Filter by Category','superblog-addons'); ?></label> 
			<select id="<?php echo esc_attr($this->get_field_id('categories')); ?>" name="<?php echo esc_attr($this->get_field_name('categories')); ?>" class="widefat categories" style="width:100%;">
				<option value='all' <?php if ('all' == $instance['categories']) echo 'selected="selected"'; ?>>all categories</option>
				<?php $categories = get_categories('hide_empty=0&depth=1&type=post'); ?>
				<?php foreach($categories as $category) { ?>
				<option value='<?php echo esc_attr($category->term_id); ?>' <?php if ($category->term_id == $instance['categories']) echo 'selected="selected"'; ?>><?php echo esc_attr($category->cat_name); ?></option>
				<?php } ?>
			</select>
		</p>
        
        <p>
			<label for="<?php echo esc_attr($this->get_field_id('layout')); ?>"><?php esc_html_e('Layout','superblog-addons'); ?>: </label>
			<select id="<?php echo esc_attr($this->get_field_id('layout')); ?>" name="<?php echo esc_attr($this->get_field_name('layout')); ?>" class="widefat">
				<?php 
				$layout_options = apply_filters('em_widget_order_ddm', array(
					'tmnf_columns_3' => esc_html__('3 Columns','superblog-addons'),
					'tmnf_columns_2' => esc_html__('2 Columns','superblog-addons'),
					'tmnf_columns_1' => esc_html__('1 Columns','superblog-addons'),
				)); 
				?>
				<?php foreach( $layout_options as $key => $value) : ?>   
	 			<option value='<?php echo esc_attr($key); ?>' <?php echo esc_attr($key == $instance['layout']) ? "selected='selected'" : ''; ?>>
	 				<?php echo esc_html($value); ?>
	 			</option>
				<?php endforeach; ?>
			</select>
        </p>
		
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('posts')); ?>"><?php esc_html_e('Number of posts','superblog-addons'); ?></label>
			<input class="widefat" style="width: 40px;" id="<?php echo esc_attr($this->get_field_id('posts')); ?>" name="<?php echo esc_attr($this->get_field_name('posts')); ?>" value="<?php echo esc_attr($instance['posts']); ?>" />
		</p>
		
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('offset_posts')); ?>"><?php esc_html_e('Offset posts','superblog-addons'); ?></label>
			<input class="widefat" style="width: 40px;" id="<?php echo esc_attr($this->get_field_id('offset_posts')); ?>" name="<?php echo esc_attr($this->get_field_name('offset_posts')); ?>" value="<?php echo esc_attr($instance['offset_posts']); ?>" />
		</p>
        
        <p>
            <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'excerpt_dis' ); ?>" name="<?php echo $this->get_field_name( 'excerpt_dis' ); ?>"<?php checked( $excerpt_dis ); ?> />
			<label for="<?php echo $this->get_field_id( 'excerpt_dis' ); ?>"><?php  esc_html_e('Disable Excerpt','superblog-addons');  ?></label>
        </p>
        
        <p>
            <input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'center_text' ); ?>" name="<?php echo $this->get_field_name( 'center_text' ); ?>"<?php checked( $center_text ); ?> />
			<label for="<?php echo $this->get_field_id( 'center_text' ); ?>"><?php  esc_html_e('Center Text','superblog-addons');  ?></label>
        </p>
        
        <p>
			<label for="<?php echo esc_attr($this->get_field_id('title_size')); ?>"><?php esc_html_e('Titles Size','superblog-addons'); ?>: </label>
			<select id="<?php echo esc_attr($this->get_field_id('title_size')); ?>" name="<?php echo esc_attr($this->get_field_name('title_size')); ?>" class="widefat">
				<?php 
				$layout_options = apply_filters('em_widget_order_ddm', array(
					'tmnf_titles_are_medium' => esc_html__('Medium Titles','superblog-addons'),
					'tmnf_titles_are_small' => esc_html__('Small Titles','superblog-addons'),
				)); 
				?>
				<?php foreach( $layout_options as $key => $value) : ?>   
	 			<option value='<?php echo esc_attr($key); ?>' <?php echo esc_attr($key == $instance['title_size']) ? "selected='selected'" : ''; ?>>
	 				<?php echo esc_html($value); ?>
	 			</option>
				<?php endforeach; ?>
			</select>
        </p>
		
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('tags_selection')); ?>"><?php esc_html_e('Filter by a tag (write tags separated by commas)','superblog-addons'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('tags_selection')); ?>" name="<?php echo esc_attr($this->get_field_name('tags_selection')); ?>" value="<?php echo esc_attr($instance['tags_selection']); ?>" />
		</p>

	<?php }
}
?>