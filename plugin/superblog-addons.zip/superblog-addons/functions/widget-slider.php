<?php
add_action('widgets_init', 'superblogaddons_slider_widget');

function superblogaddons_slider_widget()
{
	register_widget('superblogaddons_slider_widget');
}

class superblogaddons_slider_widget extends WP_Widget {
	
	public function __construct() {
		$widget_ops = array('classname' => 'superblogaddons_slider_widget', 'description' => esc_html__('!!Posts block for Elementor only!!','superblog-addons'));
       	parent::__construct(false, esc_html__('Themnific: Slider','superblog-addons'),$widget_ops);  
	}
	
	function widget($args, $instance)
	{
		extract($args);
		
		$post_type = 'all';
		$categories = isset( $instance['categories'] ) ? esc_attr( $instance['categories'] ) : '';
		$posts = isset( $instance['posts'] ) ? esc_attr( $instance['posts'] ) : '';
		$offset_posts = isset( $instance['offset_posts'] ) ? esc_attr( $instance['offset_posts'] ) : '';
		$tags_selection = isset( $instance['tags_selection'] ) ? esc_attr( $instance['tags_selection'] ) : '';
		
		echo wp_kses_post($before_widget);
		?>
		
		<?php
		$post_types = get_post_types();
		unset($post_types['page'], $post_types['attachment'], $post_types['revision'], $post_types['nav_menu_item']);
		
		if($post_type == 'all') {
			$post_type_array = $post_types;
		} else {
			$post_type_array = $post_type;
		}
		?>
            
			<?php
			$recent_posts = new WP_Query(array(
				'showposts' => $posts,
				'ignore_sticky_posts' => 1,
				'cat' => $categories,
				'offset' => esc_attr($offset_posts),
				'post_status' => 'publish',
				'tag' => esc_attr($tags_selection)
			));
			
		
			wp_enqueue_script('owl-carousel', plugin_dir_url(__DIR__).'assets/js/owl.carousel.min.js','','', true);
			wp_enqueue_script('owl-slider-start', plugin_dir_url(__DIR__).'assets/js/owl.slider.start.js','','', true);
			

			
			?>
            
            <div class="tmnf_slider_wrap">
            
                <img class="slider_spinner" src="<?php echo plugin_dir_url(__DIR__).'assets/images/tail-spin.svg'; ?>" width="40" alt="">
                
                <div class="tmnf_slider tmnf_slider_wide loop owl-carousel loading">
                
					<?php while($recent_posts->have_posts()): $recent_posts->the_post();?>
                    
                    	<?php get_template_part('/post-types/post-slider'); ?>                           
                        
                	<?php endwhile; wp_reset_postdata(); ?>
                
			    </div> <!-- end .tmnf_slider -->
                
    		</div> <!-- end .tmnf_slider_wrap -->
            
			<div class="clearfix"></div>
		
		<?php
		echo wp_kses_post($after_widget);
	}
	
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['post_type'] = 'all';
		$instance['categories'] = $new_instance['categories'];
		$instance['posts'] = sanitize_text_field($new_instance['posts']);
		$instance['offset_posts'] = sanitize_text_field($new_instance['offset_posts']);
		$instance['tags_selection'] = sanitize_text_field($new_instance['tags_selection']);
		
		return $instance;
	}

	function form($instance)
	{
		$defaults = array( 'categories' => '', 'posts' => 4,'tags_selection' => '' );
		$instance = wp_parse_args((array) $instance, $defaults); ?>

		
		
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('categories')); ?>"><?php esc_html_e('Filter by Category','superblog-addons'); ?></label> 
			<select id="<?php echo esc_attr($this->get_field_id('categories')); ?>" name="<?php echo esc_attr($this->get_field_name('categories')); ?>" class="widefat categories" style="width:100%;">
				<option value='all' <?php if ('all' == $instance['categories']) echo 'selected="selected"'; ?>>all categories</option>
				<?php $categories = get_categories('hide_empty=0&depth=1&type=post'); ?>
				<?php foreach($categories as $category) { ?>
				<option value='<?php echo esc_attr($category->term_id); ?>' <?php if ($category->term_id == $instance['categories']) echo 'selected="selected"'; ?>><?php echo esc_attr($category->cat_name); ?></option>
				<?php } ?>
			</select>
		</p>
		
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('offset_posts')); ?>"><?php esc_html_e('Offset posts','superblog-addons'); ?></label>
			<input class="widefat" style="width: 40px;" id="<?php echo esc_attr($this->get_field_id('offset_posts')); ?>" name="<?php echo esc_attr($this->get_field_name('offset_posts')); ?>" value="<?php echo esc_attr($instance['offset_posts']); ?>" />
		</p>
		
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('posts')); ?>"><?php esc_html_e('Number of posts','superblog-addons'); ?></label>
			<input class="widefat" style="width: 40px;" id="<?php echo esc_attr($this->get_field_id('posts')); ?>" name="<?php echo esc_attr($this->get_field_name('posts')); ?>" value="<?php echo esc_attr($instance['posts']); ?>" />
		</p>
		
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('tags_selection')); ?>"><?php esc_html_e('Filter by a tag (write tags separated by commas)','superblog-addons'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('tags_selection')); ?>" name="<?php echo esc_attr($this->get_field_name('tags_selection')); ?>" value="<?php echo esc_attr($instance['tags_selection']); ?>" />
		</p>
		

	<?php }
}
?>