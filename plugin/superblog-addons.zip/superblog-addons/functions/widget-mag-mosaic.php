<?php
add_action('widgets_init', 'superblogaddons_mosaic');

function superblogaddons_mosaic()
{
	register_widget('superblogaddons_mosaic');
}

class superblogaddons_mosaic extends WP_Widget {
	
	public function __construct() {
		$widget_ops = array('classname' => 'superblogaddons_mosaic', 'description' => esc_html__('!!Posts block for Elementor only!!','superblog-addons'));
       	parent::__construct(false, esc_html__('Themnific: Magazine (Mosaic)','superblog-addons'),$widget_ops);  
	}
	
	function widget($args, $instance)
	{
		extract($args);
		
		$title = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$sub_title = isset( $instance['sub_title'] ) ? esc_attr( $instance['sub_title'] ) : '';
		$post_type = 'all';
		$categories = isset( $instance['categories'] ) ? esc_attr( $instance['categories'] ) : '';
		
		echo wp_kses_post($before_widget);
		?>
		
		<?php
		$post_types = get_post_types();
		unset($post_types['page'], $post_types['attachment'], $post_types['revision'], $post_types['nav_menu_item']);
		
		if($post_type == 'all') {
			$post_type_array = $post_types;
		} else {
			$post_type_array = $post_type;
		}
		?>
		
        	<?php if ( $title == "") {} else { ?>
        
                <div class="block_title">
        
                    <span><?php echo esc_attr($sub_title); ?></span>
                
                    <h2><?php echo esc_attr($title); ?></h2>
                    
                </div>
            	
            <?php } ?>
            
			<?php
			$recent_posts = new WP_Query(array(
				'showposts' => 5,
				'ignore_sticky_posts' => 1,
				'cat' => $categories,
				'post_status' => 'publish'
			));
			
			?>
            
        <div class="mosaicwrap">  
            
        <ul class="tmnf_mosaic titles_over">
        
        
        	<?php $recent_posts = new WP_Query(array('showposts' => 1,'cat' => $categories,'ignore_sticky_posts'=>1,'post_status' => 'publish'));
            while($recent_posts->have_posts()): $recent_posts->the_post(); ?>	
            <li <?php post_class('maso maso_big maso-1'); ?>>
                <?php get_template_part('/post-types/post-mosaic'); ?>     
            </li>  
        	<?php  endwhile; ?>
            
            
        	<?php $recent_posts = new WP_Query(array('showposts' => 1,'cat' => $categories,'offset' => 1,'ignore_sticky_posts'=>1,'post_status' => 'publish'));
            while($recent_posts->have_posts()): $recent_posts->the_post(); ?>
            <li <?php post_class('maso maso_small maso-2'); ?>>
                <?php get_template_part('/post-types/post-mosaic-small'); ?>       
            </li>  
        	<?php  endwhile; ?>
            
            
        	<?php $recent_posts = new WP_Query(array('showposts' => 1,'cat' => $categories,'offset' => 2,'ignore_sticky_posts'=>1,'post_status' => 'publish'));
            while($recent_posts->have_posts()): $recent_posts->the_post(); ?>
            <li <?php post_class('maso maso_small maso-3'); ?>>
                <?php get_template_part('/post-types/post-mosaic-small'); ?>      
            </li>  
        	<?php  endwhile; ?>
            
            
        	<?php $recent_posts = new WP_Query(array('showposts' => 1,'cat' => $categories,'offset' => 3,'ignore_sticky_posts'=>1,'post_status' => 'publish'));
            while($recent_posts->have_posts()): $recent_posts->the_post(); ?>
            <li <?php post_class('maso maso_small maso-4'); ?>>
                <?php get_template_part('/post-types/post-mosaic-small'); ?>     
            </li>  
        	<?php  endwhile; ?>
            
            
        	<?php $recent_posts = new WP_Query(array('showposts' => 1,'cat' => $categories,'offset' => 4,'ignore_sticky_posts'=>1,'post_status' => 'publish'));
            while($recent_posts->have_posts()): $recent_posts->the_post(); ?>	
            <li <?php post_class('maso maso_small maso-5'); ?>>
                <?php get_template_part('/post-types/post-mosaic-small'); ?>
            </li>  
        	<?php  endwhile; ?>
            
            
            
        </ul>
        
        <?php wp_reset_postdata(); ?>
            
        </div>
		
		<?php
		echo wp_kses_post($after_widget);
	}
	
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = sanitize_text_field($new_instance['title']);
		$instance['sub_title'] = sanitize_text_field($new_instance['sub_title']);
		$instance['post_type'] = 'all';
		$instance['categories'] = $new_instance['categories'];
		
		return $instance;
	}

	function form($instance)
	{
		$defaults = array('title' => '', 'sub_title' => '','post_type' => 'all', 'categories' => 'all', 'posts' => 6, 'archive_label' => '','archive_link' => '');
		$instance = wp_parse_args((array) $instance, $defaults); ?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title (optional)','superblog-addons'); ?></label>
			<input class="widefat" style="width: 100%;" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" value="<?php echo esc_attr($instance['title']); ?>" />
		</p>
        
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('sub_title')); ?>"><?php esc_html_e('Subtitle (optional)','superblog-addons'); ?></label>
			<input class="widefat" style="width: 100%;" id="<?php echo esc_attr($this->get_field_id('sub_title')); ?>" name="<?php echo esc_attr($this->get_field_name('sub_title')); ?>" value="<?php echo esc_attr($instance['sub_title']); ?>" />
		</p>
		
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('categories')); ?>"><?php esc_html_e('Filter by Category','superblog-addons'); ?></label> 
			<select id="<?php echo esc_attr($this->get_field_id('categories')); ?>" name="<?php echo esc_attr($this->get_field_name('categories')); ?>" class="widefat categories" style="width:100%;">
				<option value='all' <?php if ('all' == $instance['categories']) echo 'selected="selected"'; ?>>all categories</option>
				<?php $categories = get_categories('hide_empty=0&depth=1&type=post'); ?>
				<?php foreach($categories as $category) { ?>
				<option value='<?php echo esc_attr($category->term_id); ?>' <?php if ($category->term_id == $instance['categories']) echo 'selected="selected"'; ?>><?php echo esc_attr($category->cat_name); ?></option>
				<?php } ?>
			</select>
		</p>
		

	<?php }
}
?>