jQuery(window).load(function() {
/*global jQuery:false */
"use strict";
	
jQuery('.tmnf_slider_wide,.tmnf_slider_vetical').owlCarousel({
    center: true,
    items:1,
    loop:true,
	animateOut: 'fadeOut',
	nav:true,
	autoplay: 'true',
	autoplayTimeout:9000,
	navText: [],
	stagePadding: 0,
    margin:0,
        dots: true,
        //dotData: true,
        //dotsData: true,
		
});
  
});