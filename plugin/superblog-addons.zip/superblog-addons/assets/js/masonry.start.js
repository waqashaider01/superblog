jQuery(window).load(function() {
/*global jQuery:false */
/*jshint devel:true, laxcomma:true, smarttabs:true */
"use strict";
      var container = document.querySelector('.tmnf_masonry');
      var msnry = new Masonry( container, {
        itemSelector: '.tmnf_item',
        columnWidth: '.tmnf_item',                
      });  
      
});
