jQuery(window).load(function() {
/*global jQuery:false */
"use strict";
	
jQuery('.tmnf_carousel').owlCarousel({
    center: false,
    items:1,
    loop:true,
	animateOut: 'fadeOut',
	nav:true,
	autoplay: 'true',
	autoplayTimeout:9000,
	navText: [''],
	stagePadding: 0,
    margin:30,
        dots: false,
    responsive:{
        450:{
    		items:2,
        },
        886:{
    		items:3,
        },
        1206:{
    		items:5,
        }
	}
		
});
  
});